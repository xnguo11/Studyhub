# Geometry Fundamentals: Shapes, Angles, and Measurements

## Introduction

Geometry is the branch of mathematics that deals with shapes, sizes, and spatial relationships. From ancient architects designing pyramids to modern engineers building skyscrapers, geometry is essential for understanding the physical world. Whether you're measuring a room, calculating the area of a garden, or understanding how structures are built, geometry provides the tools to solve real-world problems. This guide will introduce you to the fundamental concepts of geometry and teach you how to work with shapes and measurements.

## Basic Geometric Terms

### Points, Lines, and Planes

**Point:** A location with no size or dimension, represented by a dot. Named with capital letters (Point A).

**Line:** A straight path extending infinitely in both directions. Contains infinite points.

**Line Segment:** A portion of a line with two endpoints. Has a definite length.

**Ray:** Starts at a point and extends infinitely in one direction.

**Plane:** A flat surface extending infinitely in all directions. Contains infinite points and lines.

### Angles

An angle is formed by two rays sharing a common endpoint (vertex).

**Angle Measurement:** Measured in degrees (°)

**Types of Angles:**
- **Acute angle:** Less than 90° (e.g., 45°)
- **Right angle:** Exactly 90° (appears as a perfect corner)
- **Obtuse angle:** Between 90° and 180° (e.g., 135°)
- **Straight angle:** Exactly 180° (a straight line)
- **Reflex angle:** Greater than 180° (e.g., 270°)

**Angle Relationships:**
- **Complementary angles:** Two angles that add up to 90°
- **Supplementary angles:** Two angles that add up to 180°
- **Vertical angles:** Opposite angles formed by intersecting lines; always equal

## Two-Dimensional Shapes

Two-dimensional shapes are flat shapes with length and width.

### Triangles

A triangle is a polygon with three sides and three angles. The sum of all angles in a triangle is always 180°.

**Types of Triangles (by sides):**
- **Equilateral:** All three sides are equal; all angles are 60°
- **Isosceles:** Two sides are equal; two angles are equal
- **Scalene:** All three sides are different lengths; all angles are different

**Types of Triangles (by angles):**
- **Acute:** All angles are less than 90°
- **Right:** One angle is 90° (contains a right angle)
- **Obtuse:** One angle is greater than 90°

**Area of a Triangle:**
Area = (1/2) × base × height

**Example:** A triangle with base 6 cm and height 4 cm
Area = (1/2) × 6 × 4 = 12 cm²

**Perimeter of a Triangle:**
Perimeter = side a + side b + side c

### Quadrilaterals

A quadrilateral is a polygon with four sides and four angles. The sum of all angles is always 360°.

**Parallelogram:** Opposite sides are parallel and equal
- Area = base × height
- Perimeter = 2(length + width)

**Rectangle:** All angles are 90°; opposite sides are equal
- Area = length × width
- Perimeter = 2(length + width)

**Square:** All sides are equal; all angles are 90°
- Area = side²
- Perimeter = 4 × side

**Rhombus:** All sides are equal; opposite angles are equal
- Area = base × height
- Perimeter = 4 × side

**Trapezoid:** One pair of parallel sides
- Area = (1/2) × (base₁ + base₂) × height
- Perimeter = sum of all four sides

### Circles

A circle is a round shape where all points are equidistant from the center.

**Key Terms:**
- **Radius:** Distance from center to edge (r)
- **Diameter:** Distance across the circle through the center (d = 2r)
- **Circumference:** Distance around the circle
- **Pi (π):** Approximately 3.14159

**Circumference Formula:**
Circumference = 2πr or πd

**Area of a Circle:**
Area = πr²

**Example:** A circle with radius 5 cm
- Circumference = 2π(5) = 10π ≈ 31.4 cm
- Area = π(5)² = 25π ≈ 78.5 cm²

### Regular Polygons

A regular polygon has all sides equal and all angles equal.

**Common Regular Polygons:**
- Pentagon: 5 sides
- Hexagon: 6 sides
- Octagon: 8 sides

## Three-Dimensional Shapes

Three-dimensional shapes have length, width, and height/depth. They have volume and surface area.

### Rectangular Prisms (Boxes)

**Volume:** V = length × width × height

**Surface Area:** SA = 2(lw + lh + wh)

**Example:** A box with length 4 cm, width 3 cm, height 2 cm
- Volume = 4 × 3 × 2 = 24 cm³
- Surface Area = 2(4×3 + 4×2 + 3×2) = 2(12 + 8 + 6) = 52 cm²

### Cubes

A special rectangular prism where all sides are equal.

**Volume:** V = side³

**Surface Area:** SA = 6 × side²

**Example:** A cube with side 3 cm
- Volume = 3³ = 27 cm³
- Surface Area = 6 × 3² = 6 × 9 = 54 cm²

### Cylinders

A shape with two circular bases and a curved side.

**Volume:** V = πr²h (where h is height)

**Surface Area:** SA = 2πr² + 2πrh

**Example:** A cylinder with radius 2 cm and height 5 cm
- Volume = π(2)²(5) = 20π ≈ 62.8 cm³
- Surface Area = 2π(2)² + 2π(2)(5) = 8π + 20π = 28π ≈ 88 cm²

### Spheres

A perfectly round three-dimensional object.

**Volume:** V = (4/3)πr³

**Surface Area:** SA = 4πr²

### Cones

A shape with a circular base and a point at the top.

**Volume:** V = (1/3)πr²h

**Surface Area:** SA = πr² + πrl (where l is slant height)

### Pyramids

A shape with a polygonal base and triangular sides meeting at a point.

**Volume:** V = (1/3) × base area × height

**Surface Area:** SA = base area + sum of triangular sides

## The Pythagorean Theorem

In a right triangle, the relationship between the sides follows a fundamental rule.

**Pythagorean Theorem:**
a² + b² = c²

Where a and b are the legs (sides forming the right angle) and c is the hypotenuse (longest side opposite the right angle).

**Example:** A right triangle with legs 3 and 4
- 3² + 4² = c²
- 9 + 16 = c²
- 25 = c²
- c = 5

## Coordinate Geometry

Coordinate geometry uses a grid to locate points and describe shapes.

**Coordinates:** Written as (x, y) where x is horizontal position and y is vertical position.

**Distance Formula:** Distance between two points = √[(x₂-x₁)² + (y₂-y₁)²]

**Midpoint Formula:** Midpoint = ((x₁+x₂)/2, (y₁+y₂)/2)

## Transformations

Transformations are changes in position or orientation of shapes.

**Translation (Slide):** Move a shape without rotating or flipping
**Reflection (Flip):** Mirror a shape across a line
**Rotation (Turn):** Turn a shape around a point
**Dilation (Scale):** Enlarge or reduce a shape's size

## Real-World Applications of Geometry

**Architecture:** Designing buildings requires understanding angles, areas, and volumes

**Construction:** Calculating materials needed using perimeter and area formulas

**Navigation:** Using coordinate systems and distances for directions

**Art and Design:** Understanding spatial relationships and proportions

**Sports:** Calculating distances, angles in games like basketball or golf

## Practice Problems

1. Find the area of a rectangle with length 8 cm and width 5 cm.
2. Calculate the circumference of a circle with radius 4 m.
3. A right triangle has legs of 5 cm and 12 cm. Find the hypotenuse.
4. Find the volume of a rectangular prism with dimensions 3 cm × 4 cm × 5 cm.
5. Calculate the surface area of a cube with side length 2 cm.
6. Find the area of a triangle with base 10 cm and height 6 cm.

## Conclusion

Geometry is the mathematics of shape and space. By mastering these fundamental concepts—understanding shapes, calculating areas and volumes, and working with angles—you've built essential skills for advanced mathematics and countless real-world applications. Geometry helps us understand the physical world, from the microscopic structures of cells to the vast architecture of buildings and cities. Keep practicing, and geometric thinking will become a natural part of how you see the world.
